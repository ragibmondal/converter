export const environment = {
  production: true,
  ga: 'G-XXXXXXXXXX', // Google Analytics Code
  adClient: 'ca-pub-xxxxxxxxxxxxxxxxxxx', // Google Adsense AdClient
  adSlot: 123123123, // Google Adsense AdSlot
  firebase: {
    apiKey: "xxxxxxxxxxxxxxxxxxxxxxxxx",
    authDomain: "xxxxxxxxxxxxxxxx.firebaseapp.com",
    databaseURL: "https://xxxxxxxxxxxxxxxx.firebaseio.com",
    projectId: "xxxxxxxxxxxxxxxx",
    storageBucket: "xxxxxxxxxxxxxxxx.appspot.com",
    messagingSenderId: "xxxxxxxxxxxx",
    appId: "xxxxxxxxxxxxxxxxxxxxxxxxx",
    measurementId: "G-XXXXXXXXXX"
  }
};