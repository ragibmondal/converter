import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-four0four',
  templateUrl: './four0four.component.html',
  styleUrls: ['./four0four.component.scss']
})
export class Four0fourComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
