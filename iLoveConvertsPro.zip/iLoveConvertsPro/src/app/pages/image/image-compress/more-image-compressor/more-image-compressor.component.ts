import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-more-image-compressor',
  templateUrl: './more-image-compressor.component.html',
  styleUrls: ['./more-image-compressor.component.css']
})
export class MoreImageCompressorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
