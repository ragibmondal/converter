import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-to-compress',
  templateUrl: './how-to-compress.component.html',
  styleUrls: ['./how-to-compress.component.css']
})
export class HowToCompressComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
