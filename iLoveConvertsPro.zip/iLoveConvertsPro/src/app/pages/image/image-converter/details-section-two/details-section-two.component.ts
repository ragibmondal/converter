import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-section-two',
  templateUrl: './details-section-two.component.html',
  styleUrls: ['./details-section-two.component.css']
})
export class DetailsSectionTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
