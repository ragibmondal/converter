import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-section-one',
  templateUrl: './details-section-one.component.html',
  styleUrls: ['./details-section-one.component.css']
})
export class DetailsSectionOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
