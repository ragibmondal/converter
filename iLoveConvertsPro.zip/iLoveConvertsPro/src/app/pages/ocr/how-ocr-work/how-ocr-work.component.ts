import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-how-ocr-work',
  templateUrl: './how-ocr-work.component.html',
  styleUrls: ['./how-ocr-work.component.scss']
})
export class HowOcrWorkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
